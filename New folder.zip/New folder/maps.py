from config import CURRENCY_CRAFT_COORDS
from images.img_paths import *
from stash.tabs.grid_tab import GridStashTab
from stash.tabs.currency_tab import CurrencyTab
from crafters.map_crafter import craft_maps
from utils.initiate_session import requires_game_ready

@requires_game_ready()
def main():
    item_class = "Map"

    source_tab = GridStashTab(
        navigation_image=SOURCE_TAB_LOCATOR,
        open_image=SOURCE_TAB_OPEN,
    )

    currency_tab = CurrencyTab(
        navigation_image=CURRENCY_TAB,
        open_image=CURRENCY_TAB_OPEN,
        craft_coords=CURRENCY_CRAFT_COORDS,
    )

    currency_tab.open()
    currency_tab.load()

    print(currency_tab.count_all())

    source_tab.open()

    craft_maps(source_tab, currency_tab, item_class)

if __name__ == "__main__":
    main()