import time
from pathlib import Path
from typing import Optional, Tuple

import pyautogui

from config import CURRENCY_CRAFT_COORDS


Coords = Tuple[int, int]

# Global baseline delay after every PyAutoGUI call
pyautogui.PAUSE = 0.05


def wait(extra: float = 0.0) -> None:
    if extra > 0:
        time.sleep(extra)


def send(text: str, extra_pause: float = 0.0) -> None:
    """
    Type literal text.
    """
    pyautogui.write(text, interval=0)
    wait(extra_pause)


def hotkey(*keys: str, extra_pause: float = 0.0) -> None:
    """
    Press a hotkey combo.
    """
    pyautogui.hotkey(*keys)
    wait(extra_pause)


def press(key: str, times: int = 1, extra_pause: float = 0.0) -> None:
    """
    Press a key multiple times.
    """
    pyautogui.press(key, presses=times, interval=0)
    wait(extra_pause)


def key_down_shift(extra_pause: float = 0.0) -> None:
    pyautogui.keyDown("shift")
    wait(extra_pause)


def key_up_shift(extra_pause: float = 0.0) -> None:
    pyautogui.keyUp("shift")
    wait(extra_pause)


def click(coords: Coords, extra_pause: float = 0.0, button: str = "left") -> None:
    """
    Mouse click.
    """
    pyautogui.moveTo(x=coords[0], y=coords[1],duration=0.1)
    pyautogui.click(x=coords[0], y=coords[1], button=button,interval=0.1)
    wait(extra_pause)


def ctrl_click(coords: Coords, extra_pause: float = 0.0, button: str = "left") -> None:
    """
    Ctrl + click.
    """
    pyautogui.keyDown("ctrl")
    try:
        pyautogui.moveTo(x=coords[0], y=coords[1],duration=0.1)
        pyautogui.click(x=coords[0], y=coords[1], button=button,interval=0.1)
    finally:
        pyautogui.keyUp("ctrl")

    wait(extra_pause)


from images.image_utils import locate_center
def click_image(
    image_path: str | Path,
    confidence: float = 0.9,
    extra_pause: float = 0.0,
    button: str = "left",
    grayscale: bool = True,
) -> bool:
    """
    Locate and click image.
    """
    coords = locate_center(
        image_path,
        confidence=confidence,
    )

    if coords is None:
        return False

    click(coords, extra_pause=extra_pause, button=button)
    return True