import logging
from images.img_paths import *
from macros.rpa_macros import *
from functools import wraps

# Configure logging (adjust level as needed)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
logger = logging.getLogger(__name__)


def is_stash_open() -> bool:
    result = locate_center(STASH_OPEN, confidence=0.8) is not None
    logger.debug(f"is_stash_open -> {result}")
    return result


def open_stash() -> bool:
    """
    Only call this when stash is known to be closed.
    """
    logger.info("Attempting to open stash...")
    result = click_image(STASH_TEXT, confidence=0.8)
    time.sleep(1)
    logger.debug(f"open_stash click result -> {result}")
    return result


def ensure_stash_open() -> bool:
    """
    Safe to call anytime.
    """
    logger.info("Ensuring stash is open...")

    if is_stash_open():
        logger.info("Stash already open.")
        return True

    logger.info("Stash not open. Trying to open...")
    if open_stash() and is_stash_open():
        logger.info("Stash opened successfully.")
        return True

    logger.warning("First attempt failed. Sending ESC to reset UI...")
    press("esc", times=5)
    time.sleep(1)

    logger.info("Retrying to open stash...")
    success = open_stash() and is_stash_open()

    if success:
        logger.info("Stash opened successfully after retry.")
    else:
        logger.error("Failed to open stash after retry.")

    return success

# from utils.initiate_session import requires_game_ready
def move_mouse_from_view():
    pyautogui.moveTo(200, 1900)

def requires_stash_open(func):
    # @requires_game_ready()
    @wraps(func)
    def wrapper(*args, **kwargs):
        move_mouse_from_view()
        logger.info(f"Running '{func.__name__}' with stash requirement...")

        if not ensure_stash_open():
            logger.error(f"Cannot run {func.__name__}: stash is not open.")
            return False

        logger.info(f"Stash confirmed open. Executing '{func.__name__}'...")
        result = func(*args, **kwargs)

        logger.debug(f"{func.__name__} returned -> {result}")
        return result

    return wrapper