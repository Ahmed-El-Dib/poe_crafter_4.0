from config import CURRENCY_CRAFT_COORDS
from images.img_paths import *
from stash.tabs.grid_tab import GridStashTab
from stash.tabs.currency_tab import CurrencyTab
from utils.initiate_session import requires_game_ready
from macros.map_parser import parse_map_mods
from map_crafter import determine_next_action_map

MAP_SUFFIX_TARGETS = [
    "of Collection",
    "of Splinters",
    "of Defiance",
    "of Imbibing",
    "of Persistence",
    "of Decaying"
]

MAP_PREFIX_TARGETS = [
    "Antagonist's",
    "Diluted",
    "Hungering",
    "Punishing",
    "Stalwart",
    "Valdo's",
]


@requires_game_ready()
def craft_maps(source_tab: GridStashTab, currency_tab: CurrencyTab, item_class: str):
    start_idx = (0, 0)

    while not source_tab.is_done(start_idx):
        next_idx = source_tab.move_next_item_to_crafter(
            item_class=item_class,
            crafting_tab=currency_tab,
            start_idx=start_idx,
            
        )

        if next_idx is None:
            break

        while True:
            map_mods = parse_map_mods(currency_tab.craft_coords)
            result = determine_next_action_map(map_mods,currency_tab)

            if result == "DONE":
                break

        start_idx = next_idx

    print("Finished all items.")

def determine_next_action_map(map, crafting_tab: CurrencyTab):
    # time.sleep(1)
    mods = map.get('mods')
    stats = map.get('stats')
    num_mods = len(mods)
    print(stats)

    if good_to_keep(mods, stats) and num_mods == 6:
        print("Perfect map found, keeping.")
       
        return "DONE"

    if good_to_keep(mods, stats):
        print("Good map, keeping.")
        
        if num_mods == 2:                 
            crafting_tab.regal()
            crafting_tab.slam(3)      
        return "DONE"
    
    if num_mods == 0: # normal
        print("Normal map, using transmute.")
        crafting_tab.trans()
    elif 0 < num_mods < 3: # magic
        if good_to_regal(mods, stats):
            crafting_tab.regal()


        elif good_to_aug(mods, stats):
            crafting_tab.aug()
        else:
            crafting_tab.alt()
    else: # rare
        crafting_tab.scoure()

    return "CONTINUE"

# if valdo's and antagonist's are both present, return true, otherwise false
def has_valdos(mods):   return any("Valdo's" in mod.get('name', '') for mod in mods)
def has_antagonists(mods):    return any("Antagonist's" in mod.get('name', '') for mod in mods)
def good_scarabs(mods, stats):
    return stats.get("more_scarabs", 0) >= 80 and has_valdos(mods)

def good_rares(mods):
    return has_valdos(mods) and has_antagonists(mods)

def good_to_aug(mods, stats):
    return  len(mods)== 1 and (stats.get("more_currency", 0) >= 40 or stats.get("more_scarabs", 0) >= 30 or stats.get("pack_size", 0) >= 20)

def double_currency(stats):    return stats.get("more_currency", 0) >= 90
def double_pack_size(stats):    return stats.get("pack_size", 0) >= 35
def currency_and_pack_size(stats):    return stats.get("more_currency", 0) >40 and stats.get("pack_size", 0) >= 20
def good_to_regal(mods, stats):
    return len(mods) == 2 and (double_currency(stats) or double_pack_size(stats))

def good_to_keep(mods, stats):
    good_p = count_prefix_targets(mods) > 1
    good_s = count_suffix_targets(mods) > 1
    return good_scarabs(mods, stats) or good_rares(mods) or double_currency(stats) or double_pack_size(stats) or good_p or good_s



#  need count prefix and count suffix and check if they match targets

def count_prefix_targets(mods):
    return sum(any(target in mod.get('name', '') for target in MAP_PREFIX_TARGETS) and mod.get('type') == 'prefix' for mod in mods)

def count_suffix_targets(mods):
    return sum(any(target in mod.get('name', '') for target in MAP_SUFFIX_TARGETS) and mod.get('type') == 'suffix' for mod in mods)
   
def count_targets(mods):
    return count_prefix_targets(mods) + count_suffix_targets(mods)